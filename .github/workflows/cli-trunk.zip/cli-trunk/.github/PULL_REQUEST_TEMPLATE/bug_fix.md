---
name: "\U0001F41B Bug fix"
about: Fix a bug in GitHub CLI

---

<!--
Please make sure you read our contributing guidelines at
https://github.com/cli/cli/blob/trunk/.github/CONTRIBUTING.md
before opening a pull request. Thanks!
-->

## Summary

closes #[issue number]

## Details

-
